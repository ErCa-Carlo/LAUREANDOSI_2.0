<?php
header("Location: laureandosi2/index.html");
exit();
?>