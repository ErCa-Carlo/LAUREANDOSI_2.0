<?php

require_once __DIR__ . '/classi/CarrieraLaureando.php';
require_once __DIR__ . '/classi/CarrieraLaureandoInf.php';
require_once __DIR__ . '/classi/ValutaFormulaLaurea.php';
require_once __DIR__ . '/classi/CalcoloReportistica.php';

use classi\CarrieraLaureando;
use classi\CarrieraLaureandoInf;
use classi\ValutaFormulaLaurea;
use classi\CalcoloReportistica;

class UnitTest
{
    public $input;
    public $expectedOutput;
    public $functionToExecute;
    public $actualOutput;

    public function __construct($input, $expectedOutput, $functionToExecute)
    {
        $this->input = $input;
        $this->expectedOutput = $expectedOutput;
        $this->functionToExecute = $functionToExecute;

        echo "Input: " . json_encode($this->input)
           . " |  Expected output: " . json_encode($this->expectedOutput) . "<br>";
    }

    public function execute($printSuccess = true)
    {
        $this->actualOutput = call_user_func($this->functionToExecute, $this->input);

        if (!$printSuccess) return;

        $success = ($this->actualOutput === $this->expectedOutput);
        echo "Output: " . json_encode($this->actualOutput);
        echo '<p style="color: ' . ($success ? 'green' : 'red') . ';">';
        echo $success ? "Success" : "Fail";
        echo '</p>';
        echo "<br>";
    }
}

    function assertAlmostEqual($a, $b, $eps = 0.001) 
    {
        return abs((float)$a - (float)$b) <= $eps;
    }
    function assertInRange($x, $min, $max) 
    {
        return is_numeric($x) && $x >= $min && $x <= $max;
    }


?>
<html>
<head>
  <title>Unit Tests</title>
</head>
<body>
<h1>Unit Tests</h1><br>
<a id="test" href="TestCompleto.php">Test Completo</a><br>

<!-- ===========================
     1) Calcolo del bonus
=========================== -->
<h3>Calcolo del bonus</h3>
<?php
function testBonus($dati)
{
    $carriera = new CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    return $carriera->idoneitaBonus;
}

$test = new UnitTest(["matricola"=>"123456","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], false, 'testBonus'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-04-30"], true,  'testBonus'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2020-01-01"], true,  'testBonus'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-05-01"], false, 'testBonus'); $test->execute();
?>
<br>

<!-- ===========================
     2) Calcolo della media (pesata)
=========================== -->
<h3>Calcolo della media</h3>
<?php
function testMedia($dati)
{
    $carriera = ($dati["cdl"] !== "t-inf")
        ? new CarrieraLaureando($dati["matricola"], $dati["cdl"], $dati["dataLaurea"])
        : new CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);

    return round($carriera->calcolaMediaPesata(), 3);
}

$test = new UnitTest(["matricola"=>"123456","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 23.655, 'testMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"234567","cdl"=>"m-ele","dataLaurea"=>"2023-01-01"], 24.559, 'testMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 25.564, 'testMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"456789","cdl"=>"m-tel","dataLaurea"=>"2023-01-01"], 32.625, 'testMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"567890","cdl"=>"m-cyb","dataLaurea"=>"2023-01-01"], 24.882, 'testMedia'); $test->execute();
?>
<br>

<!-- ===========================
     3) Calcolo della media informatica
=========================== -->
<h3>Calcolo della media informatica</h3>
<?php
function testMediaInf($dati)
{
    $carriera = new CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);
    return round($carriera->calcolaMediaInformatica(), 3);
}

$test = new UnitTest(["matricola"=>"123456","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 23.667, 'testMediaInf'); $test->execute();
$test = new UnitTest(["matricola"=>"123456","cdl"=>"t-inf","dataLaurea"=>"2020-01-01"], 23.667, 'testMediaInf'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 25.75, 'testMediaInf'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-05-01"], 25.75, 'testMediaInf'); $test->execute();
?>
<br>

<!-- ===========================
     4) Crediti totali
=========================== -->
<h3>Calcolo dei crediti totali</h3>
<?php
function testCreditiTotali($dati)
{
    $carriera = ($dati["cdl"] !== "t-inf")
        ? new CarrieraLaureando($dati["matricola"], $dati["cdl"], $dati["dataLaurea"])
        : new CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);

    $tot = 0;
    foreach ($carriera->esami as $e) { $tot += (int)$e->cfu; }
    return $tot;
}

$test = new UnitTest(["matricola"=>"123456","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 177, 'testCreditiTotali'); $test->execute();
$test = new UnitTest(["matricola"=>"234567","cdl"=>"m-ele","dataLaurea"=>"2023-01-01"], 102, 'testCreditiTotali'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 177, 'testCreditiTotali'); $test->execute();
$test = new UnitTest(["matricola"=>"456789","cdl"=>"m-tel","dataLaurea"=>"2023-01-01"], 96,  'testCreditiTotali'); $test->execute();
$test = new UnitTest(["matricola"=>"567890","cdl"=>"m-cyb","dataLaurea"=>"2023-01-01"], 120, 'testCreditiTotali'); $test->execute();
?>
<br>

<!-- ===========================
     5) Crediti che fanno media
=========================== -->
<h3>Calcolo dei crediti che fanno media</h3>
<?php
function testCreditiMedia($dati)
{
    $carriera = ($dati["cdl"] !== "t-inf")
        ? new CarrieraLaureando($dati["matricola"], $dati["cdl"], $dati["dataLaurea"])
        : new CarrieraLaureandoInf($dati["matricola"], $dati["cdl"], $dati["dataLaurea"]);

    return $carriera->calcolaCreditiValidi();
}

$test = new UnitTest(["matricola"=>"123456","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 174, 'testCreditiMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"123456","cdl"=>"t-inf","dataLaurea"=>"2020-01-01"], 165, 'testCreditiMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"234567","cdl"=>"m-ele","dataLaurea"=>"2023-01-01"], 102, 'testCreditiMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-01-01"], 165, 'testCreditiMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"345678","cdl"=>"t-inf","dataLaurea"=>"2023-05-01"], 174, 'testCreditiMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"456789","cdl"=>"m-tel","dataLaurea"=>"2023-01-01"], 96,  'testCreditiMedia'); $test->execute();
$test = new UnitTest(["matricola"=>"567890","cdl"=>"m-cyb","dataLaurea"=>"2023-01-01"], 102, 'testCreditiMedia'); $test->execute();
?>
<br>


</body>
</html>
