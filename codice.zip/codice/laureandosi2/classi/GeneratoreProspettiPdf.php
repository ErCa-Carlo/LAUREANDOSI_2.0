<?php

namespace classi;

require_once __DIR__ . '/CarrieraLaureando.php';
require_once __DIR__ . '/ProspettoPdfLaureando.php';
require_once __DIR__ . '/ProspettoPdfCommissione.php';


class GeneratoreProspettiPdf
{
    private static string $outputPath = __DIR__ . "/../prospetti_generati";     

    private array $matricole;
    private string $corsoDiLaurea;
    private string $dataLaurea; 

    public function __construct(array $matricole, string $cdl, string $dataLaurea)
    {
        if (!file_exists(self::$outputPath))    // Verifichiamo se esiste la directory dove inserire i prospetti
        {
            mkdir(self::$outputPath, 0777, true);   // Se non esiste, si crea con i permessi al massimo
        }

        $matricole = array_filter($matricole ?? [], function ($element)     // Eliminiamo elementi vuoti dall'array di matricole
        {
            return !empty($element);
        });

        if (empty($matricole))      // Se non ci sono matricole mandiamo l'eccezzione
        {
            throw new \InvalidArgumentException("Matricole non inserite");
        }

        $this->matricole = $matricole;
        $this->corsoDiLaurea = $cdl;
        $this->dataLaurea = $dataLaurea;
    }

    public function generaProspetti($test = null): void
    {
        // Array contenente tutte le carriere per il prospetto della commissione
        $carriere = array();

        // Percorso dove verranno inseriti i prospetti (prospetti_generati/cdl/data)
        $path = self::$outputPath . DIRECTORY_SEPARATOR . $this->corsoDiLaurea . DIRECTORY_SEPARATOR . $this->dataLaurea . DIRECTORY_SEPARATOR;
        if (!file_exists($path)){ mkdir($path, 0777, true);}    // Se non esiste la cartella viene creata

        if ($test !== null) {   // Per i test utilizziamo una apposita cartella
            $path = "test/generati" . DIRECTORY_SEPARATOR . $test . DIRECTORY_SEPARATOR;
        }

        // Per ogni matricola creiamo il prospetto del laureando
        foreach ($this->matricole as $matricola) 
        {
            if ($this->corsoDiLaurea == "t-inf") 
            {   
                $carriera = new CarrieraLaureandoInf($matricola, $this->corsoDiLaurea, $this->dataLaurea);
            } 
            else 
            {
                $carriera = new CarrieraLaureando($matricola, $this->corsoDiLaurea, $this->dataLaurea);
            }

            $carriere[] = $carriera;

            $prospettoLaureando = new ProspettoPdfLaureando($carriera);     
            $prospettoLaureando->prospettoLaureando->Output('F', $path . $matricola . ".pdf");  // Generiamo il pdf e lo salviamo
        }

        // Creiamo il prospetto per la commissione
        $prospettoCommissioneGenerato = new ProspettoPdfCommissione($carriere, $this->corsoDiLaurea);
        $pathProspettoCommissione = $path . "commissione-" . $this->corsoDiLaurea . "-" . $this->dataLaurea . ".pdf";
        $prospettoCommissioneGenerato->prospettoCommissione->Output('F', $pathProspettoCommissione);
    }
}