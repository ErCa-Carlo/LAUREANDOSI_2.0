<?php

namespace classi;


class EsameLaureando
{
    public string $nome;
    public string $codice;
    public int    $voto;
    public int    $cfu;
    public string $data;
    public bool   $media = true;
    public bool   $inf = false;

    public function __construct(
        string $nome,
        string $codice,
        int    $voto,
        int    $cfu,
        string $data,
        bool   $media = true,
        bool   $inf = false
    ) 
    {
        $this->nome = $nome;
        $this->codice = $codice;
        $this->cfu = $cfu;
        $this->media = $media;
        $this->inf = $inf;
        $this->voto = $voto;

        if ($this->voto == 0) 
        {
            $this->media = false;
        }

        $data = str_replace('/', '-', $data);
        $this->data = date('Y-m-d', strtotime($data));
    }
}
