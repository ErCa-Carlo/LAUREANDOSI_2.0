<?php

namespace classi;

require_once __DIR__ . '/CarrieraLaureando.php';
require_once __DIR__ . '/CarrieraLaureandoInf.php';
require_once __DIR__ . '/GestioneCarrieraStudente.php';
require_once __DIR__ . '/CalcoloReportistica.php';

use FPDF;
require_once __DIR__ . '/../lib/fpdf184/fpdf.php';


class ProspettoPdfLaureando
{
    protected static string $pathCdl = 'config/cdl.json';
    public FPDF $prospettoLaureando;
    public CarrieraLaureando $carriera;

    public function __construct(CarrieraLaureando $carriera)
    {
        $this->carriera = $carriera;
        $this->prospettoLaureando = new FPDF();
        $this->generaPdfLaureando();
        $this->prospettoLaureando->Close();
    }

    protected function generaPdfLaureando(): void
    {
        // Config CdL
        $file = file_get_contents(self::$pathCdl);
        $config = json_decode($file, true);

        $cdlCorto = $this->carriera->corsoDiLaurea;
        $nomeCdl  = $config[$cdlCorto]['nome'] ?? $cdlCorto;
        $creditiNecessari = $config[$cdlCorto]['crediti_totali'] ?? 0;
        $formulaVoto      = $config[$cdlCorto]['formula'] ?? '';
        $inf              = $this->carriera instanceof CarrieraLaureandoInf;

        // Scelta parametro variabile per formula (T o C) come da config
        $parametro = null;
        if (!empty($config[$cdlCorto]['range_T']) &&
            $config[$cdlCorto]['range_T']['max'] !== 0 &&
            $config[$cdlCorto]['range_T']['min'] !== 0 &&
            $config[$cdlCorto]['range_T']['step'] !== 0) 
        {
            $parametro = 'T';
        } 
        elseif (!empty($config[$cdlCorto]['range_C']) &&
            $config[$cdlCorto]['range_C']['max'] !== 0 &&
            $config[$cdlCorto]['range_C']['min'] !== 0 &&
            $config[$cdlCorto]['range_C']['step'] !== 0) 
        {
            $parametro = 'C';        
        }

        // Pagina
        $this->prospettoLaureando->AddPage();
        $padding = 20;
        $larghezzaPagina = $this->prospettoLaureando->GetPageWidth() - $padding;

        // Titoli centrati
        $this->prospettoLaureando->SetFont('Arial', 'B', 14);
        $this->prospettoLaureando->Cell(0, 7, $nomeCdl, 0, 1, 'C');
        $this->prospettoLaureando->SetFont('Arial', '', 12);
        $this->prospettoLaureando->Cell(0, 6, 'CARRIERA E SIMULAZIONE DEL VOTO DI LAUREA', 0, 1, 'C');
        $this->prospettoLaureando->Ln(3);

        // Anagrafica
        $anagrafica = [
            'Matricola' => $this->carriera->matricola,
            'Nome'      => $this->carriera->nome,
            'Cognome'   => $this->carriera->cognome,
            'Email'     => $this->carriera->emailAteneo,
            'Data'      => $this->carriera->dataLaurea,
        ];
        if ($inf) 
        {
            $anagrafica['Bonus'] = $this->carriera->idoneitaBonus ? 'SI' : 'NO';
        }
        $this->aggiungiBoxDatiCompatto(
            altezzaRiga: 5,
            spazioChiave: 45,
            larghezzaTotale: $larghezzaPagina,
            dimFont: 9,
            dati: $anagrafica
        );
        $this->prospettoLaureando->Ln(3);

        // Tabella esami
        $this->aggiungiTabellaEsamiCompatta(
            altezzaRiga: 4.5,
            larghezzaDato: 18,  
            larghezzaTotale: $larghezzaPagina,
            dimFont: 9,
            esami: $this->carriera->esami,
            mostraInf: $inf
        );
        $this->prospettoLaureando->Ln(3);

        // Controllo crediti necessari
        if ($this->carriera->calcolaCreditiConseguiti() < $creditiNecessari) 
        {
            throw new \Exception($this->carriera->matricola . ' non ha abbastanza crediti per la laurea.');
        }

        // Indicatori e formula
        $indicatori = [
            'Media Pesata (M)'                 => rtrim(number_format($this->carriera->calcolaMediaPesata(), 3), '0'),
            'Crediti che fanno media (CFU)'    => $this->carriera->calcolaCreditiValidi(),
            'Crediti curricolari conseguiti'    => (string)$this->carriera->calcolaCreditiConseguiti() . '/' . $creditiNecessari,
        ];
        if ($parametro === 'T') {
            $indicatori['Voto di tesi (T)'] = 0;
        }
        if ($inf) 
        {   // Media pesata degli esami informatici
            $indicatori['Media pesata esami INF'] = rtrim(number_format($this->carriera->calcolaMediaInformatica(), 3), '0');
        }
        $indicatori['Formula calcolo voto di laurea'] = $formulaVoto;

        $this->aggiungiBoxDatiCompatto(
            altezzaRiga: 5,
            spazioChiave: 70,
            larghezzaTotale: $larghezzaPagina,
            dimFont: 9,
            dati: $indicatori
        );
        $this->prospettoLaureando->Ln(2);
    }


    /// Utility ///
    // Funzione che permette di aggiungere il "contorno" (rettangolare)
    private function aggiungiBoxDatiCompatto(
        float $altezzaRiga,
        float $spazioChiave,
        float $larghezzaTotale,
        float $dimFont,
        array $dati
    ): void 
    {
        $x = $this->prospettoLaureando->GetX();
        $y = $this->prospettoLaureando->GetY();

        $this->prospettoLaureando->SetFont('Arial', '', $dimFont);

        $this->prospettoLaureando->Rect($x, $y, $larghezzaTotale, $altezzaRiga * count($dati));

        foreach ($dati as $chiave => $valore) 
        {
            $this->prospettoLaureando->Cell($spazioChiave, $altezzaRiga, $chiave . ':', 0, 0);
            $this->prospettoLaureando->Cell($larghezzaTotale - $spazioChiave, $altezzaRiga, (string)$valore, 0, 1);
        }
    }
    
    // Funzione che aggiunge la tabella degli esami
    private function aggiungiTabellaEsamiCompatta(
        float $altezzaRiga,
        int $larghezzaDato,
        int $larghezzaTotale,
        float $dimFont,
        array $esami,
        bool $mostraInf
    ): void 
    {
        $this->prospettoLaureando->SetFont('Arial', '', $dimFont);

        // 3 colonne dati (CFU, VOT, MED) + (opzionale) INF
        $numColDati = 3 + ($mostraInf ? 1 : 0);
        $larghezzaNome = $larghezzaTotale - ($numColDati * $larghezzaDato);

        // Header
        $this->prospettoLaureando->SetFont('Arial', '', $dimFont);
        $this->prospettoLaureando->Cell($larghezzaNome, $altezzaRiga * 1.3, 'ESAME', 1, 0, 'C');
        $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga * 1.3, 'CFU', 1, 0, 'C');
        $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga * 1.3, 'VOT', 1, 0, 'C');
        $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga * 1.3, 'MED', 1, 0, 'C');
        if ($mostraInf) 
        {
            $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga * 1.3, 'INF', 1, 0, 'C');
        }
        $this->prospettoLaureando->Ln();

        // Righe
        $this->prospettoLaureando->SetFont('Arial', '', $dimFont * 0.9);
        foreach ($esami as $esame) 
        {
            $this->prospettoLaureando->Cell($larghezzaNome, $altezzaRiga, $esame->nome, 1, 0);
            $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga, $esame->cfu, 1, 0, 'C');
            $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga, $esame->voto, 1, 0, 'C');
            $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga, $esame->media ? 'X' : '', 1, 0, 'C');
            if ($mostraInf) 
            {
                $this->prospettoLaureando->Cell($larghezzaDato, $altezzaRiga, $esame->inf ? 'X' : '', 1, 0, 'C');
            }
            $this->prospettoLaureando->Ln();
        }
    }

    public function aggiungiProspettoLaureando(FPDF $pdf): void
    {
        $this->prospettoLaureando = $pdf;
        $this->generaPdfLaureando();
    }

}
