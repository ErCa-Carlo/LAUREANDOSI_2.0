<?php

namespace classi;

require_once __DIR__ . '/CarrieraLaureando.php';
require_once __DIR__ . '/GestioneCarrieraStudente.php';
require_once __DIR__ . '/ElencoEsamiInformatici.php';


class CarrieraLaureandoInf extends CarrieraLaureando
{
    public bool $idoneitaBonus;
    private int $annoImmatricolazione;

    public function __construct(string $matricola, string $cdl, string $dataLaurea)
    {
        // Creazione della classe padre
        parent::__construct($matricola, $cdl, $dataLaurea);

        // Individuiamo gli esami di informatica
        $esamiInf = ElencoEsamiInformatici::instance();
        foreach ($this->esami as $esame) {

            if (in_array($esame->nome, $esamiInf->esamiInf)) 
            {
                $esame->inf = true;
            }
        }

        // Recuperiamo la data di immatricolazione (x verificare il bonus)
        $jsonCarriera = GestioneCarrieraStudente::prelevaCarriera($matricola);
        $carriera = json_decode($jsonCarriera, true);

        $this->annoImmatricolazione = $carriera[0]["ANNO_IMM"];

        $this->idoneitaBonus = $this->calcolaBonus();
        $this->applicaBonus();
    }

    private function calcolaBonus(): bool
    {
        $data_limite = ($this->annoImmatricolazione + 4) . "-04-30";
        if (strtotime($this->dataLaurea) <= strtotime($data_limite)) 
        {
            return true;
        } 
        else 
        {
            return false;
        }
    }

    private function applicaBonus(): void
    {
        if (!$this->idoneitaBonus) {
            return;
        }
        $esameDaTogliere = null;
        foreach ($this->esami as $esame)
        {
            if ($esame->media) 
            {
                if ($esameDaTogliere === null || $esame->voto < $esameDaTogliere->voto || ($esame->voto == $esameDaTogliere->voto && $esame->cfu > $esameDaTogliere->cfu)) 
                {
                    $esameDaTogliere = $esame;
                }
            }
        }
        if ($esameDaTogliere !== null) {
            $esameDaTogliere->media = false;
        }
    }

    public function calcolaMediaInformatica(): float
    {
        $somma = 0;
        $crediti = 0;
        foreach ($this->esami as $esame) 
        {
            if ($esame->inf) 
            {
                $somma += $esame->voto * $esame->cfu;
                $crediti += $esame->cfu;
            }
        }
        if ($crediti == 0) 
        {
            return 0;
        }
        return $somma / $crediti;
    }

}
