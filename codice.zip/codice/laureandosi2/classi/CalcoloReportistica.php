<?php

namespace classi;


class CalcoloReportistica
{
    // Percorsi dei file di configurazione
    public const PATH_CDL       = __DIR__ . '/../config/cdl.json';
    public const PATH_FILTRI    = __DIR__ . '/../config/filtri.json';
    public const PATH_ESAMI_INF = __DIR__ . '/../config/esami_inf.json';

    // Ritorna l’intera config del CdL 
    public static function getCdlConfig(string $cdl): array
    {
        $all = self::readJson(self::PATH_CDL);
        if (!isset($all[$cdl]) || !is_array($all[$cdl])) {
            throw new \Exception("Configurazione CdL non trovata per: {$cdl}");
        }
        return $all[$cdl];
    }

    // Restituisce il Valore "lode" (default 33 se assente)
    public static function getLodeValue(string $cdl): float
    {
        $cfg = self::getCdlConfig($cdl);
        return (float)($cfg['lode'] ?? 33);
    }

    // Restituisce Formula voto di laurea (stringa con M, CFU, T, C). 
    public static function getFormulaVoto(string $cdl): string
    {
        $cfg = self::getCdlConfig($cdl);
        $formula = $cfg['formula'] ?? null;
        if (!is_string($formula) || trim($formula) === '') {
            throw new \Exception("Formula del voto mancante per: {$cdl}");
        }
        // Piccolo controllo M deve sempre essere presente
        if (!preg_match('/M/', $formula)) {
            throw new \Exception("Formula non valida (manca M) per: {$cdl}");
        }
        return $formula;
    }

    // Restituisce il parametro variabile: 'T', 'C' oppure null se nessuno è attivo.
    // Usiamo la funzione rangeIsActive per stabilire se il parametro è "attivo" cioè se max>min e step>0
    public static function getParametroVariabile(string $cdl): ?string
    {
        $cfg = self::getCdlConfig($cdl);
        $t = $cfg['range_T'] ?? null;
        $c = $cfg['range_C'] ?? null;

        $T_attivo = self::rangeIsActive($t);
        $C_attivo = self::rangeIsActive($c);

        if ($T_attivo && !$C_attivo) return 'T';
        if ($C_attivo && !$T_attivo) return 'C';

        return null;
    }

    // Restituisce il Range min/max/step del parametro ('T' o 'C'). 
    public static function getRange(string $cdl, string $parametro): array
    {
        $parametro = strtoupper($parametro);
        if (!in_array($parametro, ['T','C'], true)) {
            throw new \Exception("Parametro non valido: {$parametro}");
        }
        $cfg = self::getCdlConfig($cdl);
        $rng = $cfg['range_'.$parametro] ?? null;
        if (!self::rangeIsActive($rng)) {
            throw new \Exception("Range non attivo per {$parametro} nel CdL {$cdl}");
        }
        return [
            'min'  => (float)$rng['min'],
            'max'  => (float)$rng['max'],
            'step' => (float)$rng['step'],
        ];
    }

    // Restituisce il Corpo dell’email.
    public static function getEmailBody(string $cdl): string
    {
        $cfg = self::getCdlConfig($cdl);
        return (string)($cfg['corpo_email'] ?? ''); 
    }

    // Costruiamo l'Oggetto dell’email (subject).
    public static function getEmailSubject(string $cdl): string
    {
        $cfg  = self::getCdlConfig($cdl);
        $nome = $cfg['nome'] ?? $cdl;
        $sugg = 'Appello di laurea in '.$nome.' - indicatori per voto di laurea';
        $subj = trim((string)($cfg['oggetto_email'] ?? ''));
        return $subj !== '' ? $subj : $sugg;
    }

    // Restituisce la Nota della commissione da appendere nel prospetto. 
    public static function getCommissionNote(string $cdl): string
    {
        $cfg = self::getCdlConfig($cdl);
        return (string)($cfg['msg_commissione'] ?? '');
    }

    
    /// Utility /// 
    // rangeIsActive per stabilire se il parametro è "attivo" cioè se max>min e step>0
    private static function rangeIsActive(?array $rng): bool
    {
        if (!is_array($rng)) return false;
        if (!isset($rng['min'], $rng['max'], $rng['step'])) return false;
        $min = (float)$rng['min']; $max = (float)$rng['max']; $step = (float)$rng['step'];
        return $step > 0 && $max > $min;
    }
    // Funzione che legge in modo controllato il file json che si trova in un certo percorso dato
    private static function readJson(string $path): array
    {
        if (!is_file($path)) throw new \Exception("File non trovato: {$path}");
        $raw = @file_get_contents($path);
        if ($raw === false) throw new \Exception("Impossibile leggere: {$path}");
        $data = json_decode($raw, true);
        if (!is_array($data)) throw new \Exception("Formato JSON non valido: {$path}");
        return $data;
    }

}
