<?php

namespace classi;


class FiltroEsami
{    
    public string $matricola;
    public array $esamiDaTogliere; 
    public array $esamiNonMedia;
    private static string $pathFiltri = "config/filtri.json"; 

    public function __construct(string $matricola, string $cdl)
    {
        if (!file_exists(self::$pathFiltri)) 
        {
            error_log("File dei filtri non trovato.");
            return;
        }

        $this->matricola = $matricola;

        $file = file_get_contents(self::$pathFiltri);
        $config = json_decode($file, true);

        $this->esamiDaTogliere = [];
        $this->esamiNonMedia = [];

        if (isset($config[$cdl]['*'])) 
        {
            $filtro_generico = $config[$cdl]['*'];
            $this->esamiDaTogliere = $filtro_generico['da_togliere'] ?? [];
            $this->esamiNonMedia = $filtro_generico['non_media'] ?? [];
        }

        if (isset($config[$cdl][$matricola])) 
        {
            $filtro_matricola = $config[$cdl][$matricola];
            $this->esamiDaTogliere = array_merge($this->esamiDaTogliere, $filtro_matricola['da_togliere'] ?? []);
            $this->esamiNonMedia = array_merge($this->esamiNonMedia, $filtro_matricola['non_media'] ?? []);
        }

        $this->esamiDaTogliere = array_unique($this->esamiDaTogliere);
        $this->esamiNonMedia = array_unique($this->esamiNonMedia);
    }
}