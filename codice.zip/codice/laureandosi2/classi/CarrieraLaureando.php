<?php

namespace classi;

require_once __DIR__ . '/GestioneCarrieraStudente.php';
require_once __DIR__ . '/FiltroEsami.php';
require_once __DIR__ . '/EsameLaureando.php';
require_once __DIR__ . '/CalcoloReportistica.php';


class CarrieraLaureando
{
    public string $matricola;
    public string $nome;
    public string $cognome;
    public string $emailAteneo;
    public string $corsoDiLaurea;
    public array  $esami = [];       
    public string $dataLaurea;


    public function __construct(string $matricola, string $cdl, string $dataLaurea)
    {
        $this->corsoDiLaurea = $cdl;

        // Recuperoamo l'Anagrafica
        $json_anagrafica = GestioneCarrieraStudente::prelevaAnagrafica($matricola);
        $anagrafica = json_decode($json_anagrafica, true);

        $this->nome = $anagrafica["nome"];
        $this->cognome = $anagrafica["cognome"];
        $this->emailAteneo = $anagrafica["email_ate"];
        $this->matricola = $matricola;
        $this->dataLaurea = $dataLaurea;

        // Creiamo il Filtro per gli esami 
        $filtro = new FiltroEsami($matricola, $cdl);        

        // Recuperiamo la Carriera
        $jsonCarriera = GestioneCarrieraStudente::prelevaCarriera($matricola);
        $carriera = json_decode($jsonCarriera, true);

        // Recuperiamo gli esami
        foreach ($carriera as $esame) 
        {               
            if ($esame["MOT_STASTU_COD"] == "IMM") { continue; }    // Se l'esame non è curriculare non si inserisce            
            if (array_search($esame["DES"], $filtro->esamiDaTogliere) !== false) { continue; }  // Se l'esame fa parte tra quelli da togliere non si inserisce
            
            $media = array_search($esame["DES"], $filtro->esamiNonMedia) === false;

            // Recuperiamo il valore della lode
            $voto = $esame['VOTO'];
            $voto_finale = 0;
            if (is_string($voto)) 
            {
                $s = strtolower(trim($voto));
                if ($s === '30 e lode' || $s === '30elode' || $s === '30 l' || $s === '30l' || preg_match('/30.*lode/u', $s)) 
                {
                    $voto_finale = (int) CalcoloReportistica::getLodeValue($this->corsoDiLaurea);
                } 
                elseif ($s === '' || $s === 'null') 
                {
                    $voto_finale = 0;
                } 
                else 
                {
                    $voto_finale = (int) $voto;
                }
            } 
            else 
            {
                $voto_finale = (int) $voto;
            }

            $nuovo_esame = new EsameLaureando($esame["DES"], $esame["COD"], $voto_finale, $esame["PESO"], $esame["DATA_ESAME"], $media);

            $this->esami[] = $nuovo_esame;
        }

        // Mettiamo fli esami in ordine di data
        usort($this->esami, function ($a, $b) 
        {
            return strtotime($a->data) - strtotime($b->data);
        });
    }

    public function calcolaMediaPesata(): float
    {
        $somma = 0;
        $crediti = 0;
        foreach ($this->esami as $esame) {
            if ($esame->media) {
                $somma += $esame->voto * $esame->cfu;
                $crediti += $esame->cfu;
            }
        }
        if ($crediti == 0) {
            return 0;
        }
        return $somma / $crediti;
    }

    public function calcolaCreditiValidi(): int
    {
        $crediti = 0;
        foreach ($this->esami as $esame) {
            if ($esame->media) {
                $crediti += $esame->cfu;
            }
        }
        return $crediti;
    }

    public function calcolaCreditiConseguiti(): int
    {
        $crediti = 0;
        foreach ($this->esami as $esame) {
            $crediti += $esame->cfu;
        }
        return $crediti;
    }

}