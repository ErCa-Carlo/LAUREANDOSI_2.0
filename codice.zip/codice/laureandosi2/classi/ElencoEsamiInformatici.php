<?php

namespace classi;


class ElencoEsamiInformatici
{
    private static string $pathElenco = "config/esami_inf.json"; 
    private static ElencoEsamiInformatici $istanza;
    public array $esamiInf;

    private function __construct()
    {
        if (!file_exists(self::$pathElenco))    
        {
            error_log("File degli esami informatici non trovato.");
            return; 
        }

        $this->esamiInf = json_decode(file_get_contents(self::$pathElenco), true);
    }

    // Implementiamo il Singleton, garantiamo che la classe abbia una sola istanza
    public static function instance(): ElencoEsamiInformatici
    {
        if (!isset(self::$istanza)) 
        {
            self::$istanza = new ElencoEsamiInformatici();
        }
        return self::$istanza;
    }
}


