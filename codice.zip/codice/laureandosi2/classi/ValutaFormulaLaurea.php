<?php

namespace classi;


class ValutaFormulaLaurea
{
    // Caratteri permessi nell’espressione dopo la sostituzione dei token
    private const caratteriConsentiti = "0123456789+-*/(). ";


    // Calcola il voto di laurea per il CdL indicato, valutando la formula del JSON.
    public static function valutaFormula(string $cdl, float $media, int $cfu, float $parametroVal = 0.0): float
    {
        // 1) Scopri quale parametro è variabile: 'T', 'C' o null
        $parametro = CalcoloReportistica::getParametroVariabile($cdl);
        $T = 0.0; $C = 0.0;
        if ($parametro === 'T') $T = $parametroVal;
        if ($parametro === 'C') $C = $parametroVal;

        // 2) Recupera la formula testuale (con M, CFU, T, C)
        $formula = CalcoloReportistica::getFormulaVoto($cdl);

        // 3) Sostituzione token => espressione numerica
        $map = [
            'CFU' => (string)$cfu,
            'M'   => self::numToStr($media),
            'T'   => self::numToStr($T),
            'C'   => self::numToStr($C),
        ];
        $expr = $formula;
        foreach (['CFU','M','T','C'] as $tk) {
            $expr = preg_replace('/\b'.$tk.'\b/', $map[$tk], $expr);
        }

        // 4) Sicurezza: niente lettere residue
        if (preg_match('/[A-Za-z]/', $expr)) {
            throw new \Exception("Formula contiene identificatori non ammessi dopo la sostituzione: {$expr}");
        }
        if (strspn($expr, self::caratteriConsentiti) !== strlen($expr)) {
            throw new \Exception("Formula contiene caratteri non permessi: {$expr}");
        }

        // 5) Valutazione
        $result = null;
        try {            
            eval('$result = ' . $expr . ';');
        } catch (\Throwable $e) {
            throw new \Exception('Errore nella valutazione della formula: '.$e->getMessage());
        }

        if (!is_finite((float)$result)) {
            throw new \Exception('Risultato della formula non valido.');
        }
        return (float)$result;
    }

    // Formatting numerico stabile
    private static function numToStr(float $n): string
    {
        return rtrim(rtrim(number_format($n, 10, '.', ''), '0'), '.');
    }
}




