<?php

namespace classi;

require_once __DIR__ . '/GestioneCarrieraStudente.php';
require_once __DIR__ . '/CalcoloReportistica.php';

require_once __DIR__ . '/../lib/PHPMailer/src/PHPMailer.php';
require_once __DIR__ . '/../lib/PHPMailer/src/Exception.php';
require_once __DIR__ . '/../lib/PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;

class InvioProspetti
{

    private static string $pathCdl = "config" . DIRECTORY_SEPARATOR . "cdl.json";
    private static string $pathProspetti = "prospetti_generati" . DIRECTORY_SEPARATOR;
    private string $corsoDiLaurea;
    private string $dataLaurea;
    private string $matricola;
    private ?string $email = null;

    public function __construct(string $matricola, string $cdl, string $dataLaurea, ?string $email = null)
    {
        if (!file_exists(self::$pathCdl)) 
        {
            throw new \Exception("Directory dei corsi di laurea non trovata.");
        }

        if ($matricola == "") 
        {
            throw new \Exception("Matricola vuota.");
        }

        $this->matricola = $matricola;
        $this->corsoDiLaurea = $cdl;
        $this->dataLaurea = $dataLaurea;
        $this->email = $email;
    }

    public function inviaProspetto($indirizzo_test = null): void
    {
        $filePath = self::$pathProspetti . $this->corsoDiLaurea . DIRECTORY_SEPARATOR . $this->dataLaurea . DIRECTORY_SEPARATOR;

        if ($indirizzo_test != null)    // Per i Test vado a cercare nella cartella apposita
        {
            $filePath = "test/generati" . DIRECTORY_SEPARATOR . $this->matricola . DIRECTORY_SEPARATOR;
        }

        $prospetto = $filePath . $this->matricola . ".pdf";
        if (!file_exists($prospetto)) 
        {
            throw new \Exception("Prospetto di " . $this->matricola . " non trovato.");
        }

        $indirizzo = $indirizzo_test    
            ?? $this->email
            ?? json_decode(GestioneCarrieraStudente::prelevaAnagrafica($this->matricola))->email_ate;

        $mail = $this->creaMail($indirizzo, $prospetto);
        if (!$mail->send()) 
        {
            throw new \Exception("Errore durante l'invio del prospetto a $this->matricola: " . $mail->ErrorInfo);
        }
    }

    private function creaMail(string $indirizzo, string $pathProspetto): PHPMailer
    {
        $mail = new PHPMailer(true);

        // Transport
        $mail->isSMTP();
        $mail->Host       = "mixer.unipi.it";
        $mail->Port       = 25;
        $mail->SMTPSecure = "tls";
        $mail->SMTPAuth   = false;

        // Intestazioni base
        $mail->CharSet = 'UTF-8';
        $mail->setLanguage('it', join(DIRECTORY_SEPARATOR, array(dirname(__DIR__), 'lib', 'PHPMailer', 'language')));
        $mail->setFrom('no-reply-laureandosi@ing.unipi.it', 'Laureandosi');
        $mail->addAddress($indirizzo);

        // Allegato: prospetto PDF del laureando
        $nomeAllegato = 'Prospetto_' . $this->matricola . '.pdf';
        $mail->addAttachment($pathProspetto, $nomeAllegato);

        // Oggetto e corpo presi dalla configurazione del CdL
        $subject = CalcoloReportistica::getEmailSubject($this->corsoDiLaurea);
        $body    = CalcoloReportistica::getEmailBody($this->corsoDiLaurea);

        $mail->Subject = $subject;   
        $mail->isHTML(false);        
        $mail->Body    = $body;     

        return $mail;
    }

}