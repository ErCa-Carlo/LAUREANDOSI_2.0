<?php

namespace classi;

require_once __DIR__ . '/CarrieraLaureando.php';
require_once __DIR__ . '/CalcoloReportistica.php';
require_once __DIR__ . '/ValutaFormulaLaurea.php';

use FPDF;
require_once __DIR__ . '/../lib/fpdf184/fpdf.php';


class SimulazioneVotoLaurea
{
    
    private ?string $parametro = null;      // 'T', 'C' oppure null (se il CdL non prevede un parametro variabile)
    private ?float $min = null;             // Valori range
    private ?float $max = null;
    private ?float $step = null;
    private array $righe = [];              // elenco righe simulazione: p = valore T/C, v = voto laurea 
    private CarrieraLaureando $carriera;    // Carriera per cui si simula

    public function __construct(CarrieraLaureando $carriera)
    {
        $this->carriera = $carriera;
        $this->costruisciSimulazione();
    }


    // Calcoliamo la griglia
    private function costruisciSimulazione(): void
    {
        $cdl     = $this->carriera->corsoDiLaurea;
        $media   = $this->carriera->calcolaMediaPesata();
        $crediti = $this->carriera->calcolaCreditiValidi();

        $this->parametro = CalcoloReportistica::getParametroVariabile($cdl);

        // Se il parametro è null, registriamo l'errore e usciamo (senza sollevare eccezioni)
        if ($this->parametro === null) 
        {
            error_log("LOGICA ERRORE: Simulazione voto ignorata. Il CdL '{$cdl}' non prevede né il parametro T né il parametro C.");
            // Non lanciamo eccezioni, la funzione termina qui
            // Questo è un errore che non voglio che l'utente vedi
            return; 
        }

        $rng        = CalcoloReportistica::getRange($cdl, $this->parametro);
        $this->min  = $rng['min'];
        $this->max  = $rng['max'];
        $this->step = $rng['step'];

        $eps = max(1e-9, $this->step / 1000.0);     // Tolleranza floating point
        for ($p = $this->min; $p <= $this->max + $eps; $p += $this->step) 
        {
            $voto = ValutaFormulaLaurea::valutaFormula($cdl, $media, $crediti, $p);
            $this->righe[] = ['p' => (float)$p, 'v' => (float)$voto];
        }
    }

    // Stampiamo sul PDF la sezione
    public function aggiungiPDFConSimulazione(FPDF $pdf): void
    {
        // Titolo sezione
        $pad = 20;
        $W   = $pdf->GetPageWidth() - $pad;

        $pdf->Ln(2);
        $pdf->SetFont('Arial', '', 10);
        $pdf->Cell($W, 6, "SIMULAZIONE DI VOTO DI LAUREA", 1, 1, 'C');

        // Intestazioni di colonna
        $labelParam = $this->parametro === 'T' ? "VOTO TESI (T)" : "VOTO COMMISSIONE (C)";

        $col1 = $W * 0.5;
        $col2 = $W - $col1;

        $pdf->Cell($col1, 6, $labelParam, 1, 0, 'C');
        $pdf->Cell($col2, 6, "VOTO LAUREA", 1, 1, 'C');

        // Righe della simulazione
        foreach ($this->righe as $r) 
        {
            $pdf->Cell($col1, 6, $this->fmt($r['p']), 1, 0, 'C');
            $pdf->Cell($col2, 6, $this->fmt($r['v']), 1, 1, 'C');
        }

        // Riga finale con istruzione
        $pdf->Ln(1.5);
        $istruzione = CalcoloReportistica::getCommissionNote($this->carriera->corsoDiLaurea);
        $pdf->MultiCell($W, 6, $istruzione, 0, 'L');
        $pdf->Ln(4);
    }

    /// Utility /// 
    // Formattazione numerica: max 3 decimali senza zeri superflui 
    private function fmt(float $n): string
    {
        return rtrim(rtrim(number_format($n, 3, '.', ''), '0'), '.');
    }

}
