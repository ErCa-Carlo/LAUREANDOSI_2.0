<?php

namespace classi;

require_once __DIR__ . '/GeneratoreProspettiPdf.php';
require_once __DIR__ . '/InvioProspetti.php';


class GUI
{

    public function __construct()
    {
    }

    public static function callGeneraProspetti(string $json, $test = null): string
    {
        $dati = json_decode($json, true);

        try 
        {   
            $generatore = new GeneratoreProspettiPdf($dati["array_matricole"], $dati["cdl"], $dati["data"]);
            $generatore->generaProspetti($test);
        } 
        catch (\Exception $e)    // Oggetto dell'eccezione
        {
            http_response_code(500);
            return json_encode(["error" => $e->getMessage(), "success" => false]);
        }

        http_response_code(200);
        return json_encode(["message" => "Prospetti generati", "success" => true]);
    }

    public static function ApriProspetti(string $cdl, string $dataLaurea): string
    {
        $directory = "prospetti_generati" . DIRECTORY_SEPARATOR . $cdl . DIRECTORY_SEPARATOR . $dataLaurea . DIRECTORY_SEPARATOR;
        $nomeFile = "commissione-" . $cdl . "-" . $dataLaurea . ".pdf";
        $percorsoFile = $directory . $nomeFile;

        if (file_exists($percorsoFile)) 
        {
            header('Content-type: application/pdf');
            header('Content-Disposition: inline; filename="Commissione_' . strtoupper($cdl) . '_' . $dataLaurea . '.pdf"');
            header('Content-Transfer-Encoding: binary');
            header('Content-Length: ' . filesize($percorsoFile));
            header('Accept-Ranges: bytes');
            readfile($percorsoFile);

            http_response_code(200);
            return json_encode(["success" => true]);
        } 
        else 
        {
            http_response_code(404);
            return json_encode(["error" => "Prospetti non trovati", "success" => false]);
        }
    }

    public static function callInviaProspetto(string $json, string $indirizzo_test = null): string
    {
        $dati = json_decode($json, true);

        try 
        {
            $dati_laureando = json_decode(GestioneCarrieraStudente::prelevaAnagrafica($dati["matricola"]));
            $email  = $dati_laureando->email_ate ?? null;

            $invioMail = new InvioProspetti($dati["matricola"], $dati["cdl"], $dati["data"], $email);
            $invioMail->inviaProspetto($indirizzo_test);
        } 
        catch (\Exception $e) 
        {
            http_response_code(500);
            return json_encode(["error" => $e->getMessage(), "success" => false]);
        }

        http_response_code(200);
        return json_encode(["success" => true]);
    }
}