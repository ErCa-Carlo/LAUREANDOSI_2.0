<?php

use classi\GUI;

require_once __DIR__ . '/classi/GUI.php';


// Classe di interfaccia tra il front-end e il back-end

// Genera Prospetti
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['GUI']) && $_GET['GUI'] === 'GeneraProspetti') 
{
    $json = file_get_contents('php://input');
    echo GUI::callGeneraProspetti($json);
}

// Apri Prospetti
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['GUI']) && $_GET['GUI'] === 'ApriProspetti') 
{
    $corso_laurea = $_GET["cdl"];
    $data_laurea = $_GET["data"];
    GUI::ApriProspetti($corso_laurea, $data_laurea);
}

// Invia Prospetti
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_GET['GUI']) && $_GET['GUI'] === 'InviaProspetti') 
{
    $json = file_get_contents('php://input');
    echo GUI::callInviaProspetto($json);
}
