/* ELEMENTI DOM */

const input_matricole = document.getElementById('matricole');
const input_cdl = document.getElementById('cdl');
const input_data = document.getElementById('data');

const btn_genera = document.getElementById('genera');
const btn_apri = document.getElementById('apri');
const btn_invia = document.getElementById('invia');

const txt_output = document.getElementById('output');

/* FUNZIONI */

function abilitaPulsanti() 
{
    btn_genera.disabled = false;
    btn_apri.disabled = false;
    btn_invia.disabled = false;
}

function disabilitaPulsanti() 
{
    btn_genera.disabled = true;
    btn_apri.disabled = true;
    btn_invia.disabled = true;
}

function mostraMessaggio(msg) 
{
    txt_output.innerText = msg;
}


function aggiungiCdl() 
{
    mostraMessaggio("Caricamento corsi di laurea...");
    fetch('config/cdl.json')
        .then(response => response.json())
        .then(data => {
            Object.keys(data).forEach(key => {
                const cdl = data[key];
                const option = document.createElement('option');
                option.value = cdl["nome_corto"];
                option.text = cdl["nome"];
                input_cdl.appendChild(option);
            });
            txt_output.innerText = "";
            abilitaPulsanti();
        })
        .catch(error => console.error('Errore nella ricerca dei corsi di laurea', error));
}

async function genera() 
{
    const matricole = (input_matricole.value || '').trim();
    const cdl       = (input_cdl.value || '').trim();
    const data      = (input_data.value || '').trim();

    // Controllo input
    if (!matricole) return mostraMessaggio("Matricole mancanti");
    if (!cdl) return mostraMessaggio("Corso di Laurea non selezionato");
    if (!data) return mostraMessaggio("Data non selezionata");

    mostraMessaggio("Generazione prospetti in corso...");
    disabilitaPulsanti();

    // Normalizza le matricole: separa per spazi multipli e rimuovi vuoti
    const array_matricole = matricole.split(/\s+/).map(s => s.trim()).filter(Boolean);


    const payload = {array_matricole, cdl, data};
    const richiesta = JSON.stringify(payload);

    
    try 
    {
        const res = await fetch("API.php?GUI=GeneraProspetti", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: richiesta
        });

        // Prova sia JSON che testo grezzo (così vediamo HTML/warning)
        let dataJson = null;
        let bodyText = null;

        try 
        { 
            dataJson = await res.clone().json(); 
        } 
        catch (_) {}

        if (dataJson === null) 
        {
            try 
            { 
                bodyText = await res.text(); 
            } 
            catch (_) {}
        }

        if (!res.ok) 
        {
            const msg = (dataJson && (dataJson.error || dataJson.message))
                     || (bodyText ? `HTTP ${res.status}: ${bodyText.substring(0, 600)}` 
                     : `HTTP ${res.status}: risposta non valida`);
            mostraMessaggio(msg);
            return;
        }

        if (!dataJson) 
        {
            const hint = bodyText ? `Dettagli:\n${bodyText.substring(0, 800)}` : '';
            mostraMessaggio(`Risposta non valida dal server.\n${hint}`);
            return;
        }

        if (dataJson.success === false) 
        {
            mostraMessaggio(dataJson.error || "Errore nella generazione dei prospetti");
            return;
        }

        mostraMessaggio(dataJson.message || "Prospetti generati con successo.");
    } 
    catch (error) 
    {
        mostraMessaggio(error?.message || "Errore nella generazione dei prospetti");
    } 
    finally 
    {
        abilitaPulsanti();
    }
    
}

async function apri() 
{
    const cdl = input_cdl.value;
    const data = input_data.value;

    const url = `API.php?GUI=ApriProspetti&cdl=${cdl}&data=${data}`;

    try 
    {
        const res = await fetch(url);
        if (!res.ok) 
        {
            throw res;
        }
        const prospetto = await res.blob();
        txt_output.innerText = "Prospetti aperti";
        window.open(window.URL.createObjectURL(prospetto), '_blank').focus();
    } 
    catch (err)
    {
        txt_output.innerText = "Errore nell'apertura dei prospetti";
    }
}

async function invia() 
{
    mostraMessaggio("Invio in corso...");
    disabilitaPulsanti();

    const matricole = input_matricole.value;
    const cdl = input_cdl.value;
    const data = input_data.value;

    const array_matricole = (matricole.split(/\s+/)).filter(matricola => matricola !== "");
    if (array_matricole.length === 0) 
    {
        mostraMessaggio("Nessuna matricola inserita");
        abilitaPulsanti();
        return;
    }

    let prospetti_totali = array_matricole.length;
    let prospetti_inviati = 0;

    for (const matricola of array_matricole) 
    {
        const richiesta = JSON.stringify({matricola, cdl, data});

        try 
        {
            const res = await fetch("API.php?GUI=InviaProspetti", {
                method: "POST", 
                headers: {
                    "Content-Type": "application/json"
                }, 
                body: richiesta
            });
            const json = await res.json();

            if (res.ok) 
            {
                await new Promise(resolve => setTimeout(resolve, 5000));
                prospetti_inviati++;
                mostraMessaggio("Prospetti inviati: " + prospetti_inviati + " di " + prospetti_totali);
            } 
            else 
            {
                mostraMessaggio(json.error);
            }
        } 
        catch (error) 
        {
            mostraMessaggio("Errore nell'invio dei prospetti");
        }
    }
    abilitaPulsanti();
}

/* EVENTI */

window.addEventListener('load', aggiungiCdl);

btn_genera.addEventListener('click', genera);
btn_apri.addEventListener('click', apri);
btn_invia.addEventListener('click', invia);

