<?php

require_once __DIR__ . DIRECTORY_SEPARATOR . 'classi' . DIRECTORY_SEPARATOR . 'GUI.php';

const INDIRIZZO_TEST = "nome.cognome@studenti.unipi.it";    // Indirizzo a cui mandare i prospetti nei test

function TestCompleto()
{
    // Pulizia test precedenti
    if (file_exists("test/generati") && is_dir("test/generati")) 
    {
        $files = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator("test/generati", RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($files as $fileinfo) 
        {
            $todo = ($fileinfo->isDir() ? 'rmdir' : 'unlink');
            $todo($fileinfo->getRealPath());
        }
    }

    // Input da testare
    $dati = array(
        (object)array('matricola' => '123456', 'cdl' => 't-inf', 'data' => '2023-01-04'),
        (object)array('matricola' => '234567', 'cdl' => 'm-ele', 'data' => '2023-01-04'),
        (object)array('matricola' => '345678', 'cdl' => 't-inf', 'data' => '2023-01-04'),
        (object)array('matricola' => '456789', 'cdl' => 'm-tel', 'data' => '2023-01-04'),
        (object)array('matricola' => '567890', 'cdl' => 'm-cyb', 'data' => '2023-01-04'),
    );

    // Generazione PDF
    foreach ($dati as $d)
    {
        $input = json_encode(array(
            "array_matricole" => array($d->matricola),
            "cdl" => $d->cdl,
            "data" => $d->data
        ));

        if (!file_exists("test/generati/" . $d->matricola)) 
        {
            mkdir("test/generati/" . $d->matricola, 0777, true);
        }

        $res = classi\GUI::callGeneraProspetti($input, $d->matricola);
        if (json_decode($res)->success ?? false) 
        {
            echo "Generato prospetto per " . $d->matricola . "<br>";
        } 
        else 
        {
            echo "ERRORE durante la generazione per $d->matricola: " . (json_decode($res)->error ?? 'Errore sconosciuto') . "<br>";
        }
    }

    echo "<br>";

    // Link ai PDF
    foreach ($dati as $d) 
    {
        echo '<a href="test/generati/' . $d->matricola . '/commissione-' . $d->cdl . '-' . $d->data . '.pdf">Visualizza prospetto generato per ' . $d->matricola . '</a>';
        echo '    |    ';
        echo '<a href="test/output_giusti/' . $d->matricola . '_output.pdf">Visualizza prospetto giusto per ' . $d->matricola . '</a>';
        echo '<br>';
    }

    echo "<br>";

    // Invio PDF via mail (verso INDIRIZZO_TEST)
    foreach ($dati as $d) {
        $input = json_encode(array("matricola" => $d->matricola, "cdl" => $d->cdl, "data" => $d->data));

        $res = classi\GUI::callInviaProspetto($input, INDIRIZZO_TEST);
        if (json_decode($res)->success ?? false)
        {
            echo "Inviato prospetto per " . $d->matricola . "<br>";
            sleep(5);
        } 
        else 
        {
            echo "ERRORE durante l'invio di $d->matricola: " . (json_decode($res)->error ?? 'Errore sconosciuto') . "<br>";
        }
    }
}

?>
<html>
<head>
  <title>Test completo</title>
</head>
<body>
<h1>Test generazione e invio prospetti</h1><br>
<?php TestCompleto(); ?>
</body>
</html>
